import os
import sqlite3
import shutil
import webbrowser
import threading
from datetime import datetime, timedelta
from flask import Flask, jsonify

app = Flask(__name__)

# ---------------------------
# CONFIG
# ---------------------------
history_path = os.path.expanduser("~/.config/google-chrome/Default/History")
temp_db = "History.db"

# ---------------------------
# TIME CONVERSION
# ---------------------------
def convert_chrome_time(chrome_time):
    try:
        return datetime(1601, 1, 1) + timedelta(microseconds=chrome_time)
    except:
        return None

# ---------------------------
# 1. BROWSER EVENTS
# ---------------------------
def get_browser_events():
    events = []
    if not os.path.exists(history_path):
        return events
    try:
        shutil.copy2(history_path, temp_db)
        conn   = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT url, last_visit_time FROM urls ORDER BY last_visit_time DESC")
        for url, t in cursor.fetchall():
            time = convert_chrome_time(t)
            if time:
                events.append({"time": time.strftime("%Y-%m-%d %H:%M:%S"), "type": "browser", "text": url})
        conn.close()
    except:
        pass
    return events

# ---------------------------
# 2. FILE EVENTS
# ---------------------------
def get_file_events():
    events = []
    for base_path in ["/home", "/etc", "/var/log"]:
        for root, dirs, files in os.walk(base_path):
            for file in files:
                if file.endswith(".txt"):
                    try:
                        path = os.path.join(root, file)
                        t    = os.path.getmtime(path)
                        events.append({"time": datetime.fromtimestamp(t).strftime("%Y-%m-%d %H:%M:%S"),
                                       "type": "file", "text": path})
                    except:
                        pass
    return events

# ---------------------------
# 3. LOG EVENTS
# ---------------------------
def get_log_events():
    import subprocess
    events = []
    try:
        result = subprocess.run(["journalctl", "-n", "50", "--no-pager", "--output=short"],
            capture_output=True, text=True, timeout=5)
        for line in result.stdout.splitlines():
            line = line.strip()
            if not line or line.startswith("--"):
                continue
            try:
                parts = line.split()
                t = datetime.strptime(f"2026 {parts[0]} {parts[1]} {parts[2]}", "%Y %b %d %H:%M:%S")
                time_fmt = t.strftime("%Y-%m-%d %H:%M:%S")
            except:
                time_fmt = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            events.append({"time": time_fmt, "type": "log", "text": "[journald] " + line[:150]})
    except:
        pass
    for log_file in ["log.txt","/var/log/dpkg.log","/var/log/alternatives.log",
                     "/var/log/bootstrap.log","/var/log/auth.log","/var/log/syslog"]:
        if os.path.exists(log_file):
            try:
                with open(log_file, "r", errors="ignore") as f:
                    for line in f.readlines()[-30:]:
                        line = line.strip()
                        if line:
                            events.append({"time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                           "type": "log", "text": f"[{os.path.basename(log_file)}] {line[:150]}"})
            except:
                pass
    return events

# ---------------------------
# 4. NETWORK EVENTS
# ---------------------------
def get_network_events():
    import subprocess
    events = []
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        result = subprocess.run(["ss", "-tnp"], capture_output=True, text=True, timeout=5)
        for line in result.stdout.splitlines()[1:]:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            events.append({"time": now, "type": "network",
                "text": f"[{parts[0] if parts else ''}] {parts[3] if len(parts)>3 else ''} -> {parts[4] if len(parts)>4 else ''}  process={parts[5] if len(parts)>5 else 'unknown'}"})
    except:
        pass
    if not events:
        try:
            with open("/proc/net/tcp", "r") as f:
                for line in f.readlines()[1:]:
                    parts = line.strip().split()
                    if len(parts) < 4:
                        continue
                    def hex_to_ip(h):
                        ip, port = h.split(":")
                        return ".".join(str(int(ip[i:i+2],16)) for i in (6,4,2,0)) + f":{int(port,16)}"
                    state = {"01":"ESTABLISHED","0A":"LISTEN","06":"TIME_WAIT"}.get(parts[3].upper(), parts[3])
                    events.append({"time": now, "type": "network",
                                   "text": f"[{state}] {hex_to_ip(parts[1])} -> {hex_to_ip(parts[2])}"})
        except:
            pass
    return events

# ---------------------------
# 5. DNS EVENTS
# ---------------------------
def get_dns_events():
    import subprocess, re
    events = []
    try:
        result = subprocess.run(["journalctl", "-n", "500", "--no-pager", "--output=short"],
            capture_output=True, text=True, timeout=8)
        pattern = re.compile(
            r"(?:query|resolved|lookup|dns|resolve)[^\n]*?([a-zA-Z0-9][-a-zA-Z0-9]*(?:\.[a-zA-Z0-9][-a-zA-Z0-9]*)+)",
            re.IGNORECASE)
        seen = set()
        for line in result.stdout.splitlines():
            if not any(kw in line.lower() for kw in ["dns","query","resolv","lookup","nxdomain"]):
                continue
            try:
                parts = line.split()
                t = datetime.strptime(f"2026 {parts[0]} {parts[1]} {parts[2]}", "%Y %b %d %H:%M:%S")
                time_fmt = t.strftime("%Y-%m-%d %H:%M:%S")
            except:
                time_fmt = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            m = pattern.search(line)
            if m:
                domain = m.group(1).lower()
                if any(s in domain for s in ["localhost","local","arpa","internal","docker","kubernetes"]):
                    continue
                if domain not in seen:
                    seen.add(domain)
                    events.append({"time": time_fmt, "type": "dns", "text": f"[DNS] {domain}  (source: journal)"})
    except:
        pass
    try:
        with open("/etc/hosts", "r") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split()
                if len(parts) >= 2:
                    for host in parts[1:]:
                        if host not in ("localhost","localhost6","ip6-localhost","ip6-loopback",
                                        "ip6-allnodes","ip6-allrouters") and "." in host:
                            events.append({"time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                           "type": "dns", "text": f"[HOSTS] {host}  ->  {parts[0]}"})
    except:
        pass
    return events

# ---------------------------
# 6. SAVE REPORT
# ---------------------------
def save_report(events):
    counts = {t: sum(1 for e in events if e["type"]==t) for t in ["browser","file","log","network","dns"]}
    with open("report.txt", "w") as f:
        f.write("=== Digital Activity Timeline ===\n\n")
        for e in events:
            f.write(f"{e['time']} -> [{e['type'].upper()}] {e['text']}\n")
        f.write("\n--- Summary ---\n")
        for k,v in counts.items():
            f.write(f"{k.capitalize():<12}: {v}\n")
        f.write(f"Total        : {len(events)}\n")
    return counts["browser"], counts["file"], counts["log"], counts["network"], counts["dns"]

# ---------------------------
# 7. ANALYZE EVENT
# ---------------------------
def analyze_event(etype, text):
    import re
    verdict, color, details, tips = "Safe", "green", [], []

    if etype == "browser":
        details.append(f"URL: {text}")
        if text.startswith("http://"):
            verdict, color = "Suspicious", "orange"
            details.append("⚠ Non-HTTPS connection (unencrypted)")
            tips.append("Prefer https:// for sensitive activity")
        else:
            details.append("✓ HTTPS connection (encrypted)")
        try:
            domain = re.findall(r"https?://([^/]+)", text)[0]
            details.append(f"Domain: {domain}")
            matched = [k for k in ["login","signin","account","verify","secure","update","banking","paypal","confirm"] if k in domain.lower()]
            if matched:
                verdict, color = "Suspicious", "orange"
                details.append(f"⚠ Suspicious keywords: {', '.join(matched)}")
                tips.append("Verify this site before entering credentials")
            if any(s in domain.lower() for s in ["google","github","stackoverflow","mozilla","python","microsoft","wikipedia","youtube"]):
                details.append("✓ Well-known trusted domain")
        except:
            pass
        if re.match(r"https?://\d+\.\d+\.\d+\.\d+", text):
            verdict, color = "Malicious", "red"
            details.append("🚨 Direct IP address URL — highly suspicious")
            tips.append("Do not enter credentials on IP-based URLs")

    elif etype == "file":
        details.append(f"Path: {text}")
        try:
            stat  = os.stat(text)
            mtime = datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S")
            atime = datetime.fromtimestamp(stat.st_atime).strftime("%Y-%m-%d %H:%M:%S")
            details += [f"Size: {stat.st_size} bytes", f"Last Modified: {mtime}", f"Last Accessed: {atime}"]
        except:
            details.append("File info could not be read")
        if any(text.startswith(p) for p in ["/tmp","/dev/shm","/var/tmp"]):
            verdict, color = "Suspicious", "orange"
            details.append("⚠ File in temporary/volatile directory")
            tips.append("Files in /tmp are often used by malware")
        if text in ["/etc/passwd","/etc/shadow","/etc/sudoers","/etc/hosts","/etc/crontab"]:
            verdict, color = "Malicious", "red"
            details.append("🚨 Critical system file accessed/modified!")
            tips.append("Verify this modification was authorized")
        if text.split("/")[-1].startswith("."):
            verdict, color = "Suspicious", "orange"
            details.append("⚠ Hidden file (starts with dot)")
            tips.append("Hidden files can conceal malicious activity")
        if color == "green":
            details.append("✓ File path appears normal")

    elif etype == "log":
        details.append(f"Raw log: {text}")
        tl = text.lower()
        if "failed" in tl or "failure" in tl:
            verdict, color = "Suspicious", "orange"
            details.append("⚠ Authentication failure detected")
            tips.append("Multiple failures may indicate brute-force attack")
        elif "denied" in tl or "unauthorized" in tl:
            verdict, color = "Malicious", "red"
            details.append("🚨 Unauthorized access attempt detected")
            tips.append("Check which user/IP triggered this")
        elif "error" in tl:
            verdict, color = "Suspicious", "orange"
            details.append("⚠ System error in log")
        elif "sudo" in tl or "root" in tl:
            verdict, color = "Suspicious", "orange"
            details.append("⚠ Privileged command (sudo/root) in log")
            tips.append("Verify this was an authorized admin action")
        else:
            details.append("✓ Log entry appears routine")

    elif etype == "network":
        details.append(f"Connection: {text}")
        tl = text.lower()
        for port, msg in {"4444":"Metasploit default 🚨","1337":"Backdoor port 🚨","31337":"Elite backdoor 🚨",
                          "6666":"IRC/botnet ⚠","6667":"IRC/botnet ⚠","23":"Telnet unencrypted ⚠","21":"FTP unencrypted ⚠"}.items():
            if f":{port}" in text:
                verdict = "Malicious" if "🚨" in msg else "Suspicious"
                color   = "red" if "🚨" in msg else "orange"
                details.append(f"Port {port}: {msg}")
                tips.append(f"Investigate process on port {port} immediately")
                break
        if "established" in tl:  details.append("Active outbound/inbound connection")
        elif "listen" in tl:     details.append("Service listening for connections")
        elif "time_wait" in tl:  details.append("Connection closing (TIME_WAIT)")
        if "0.0.0.0" in text:
            details.append("⚠ Bound to all interfaces (0.0.0.0)")
            tips.append("Check if this service should be publicly accessible")
            if color == "green": verdict, color = "Suspicious", "orange"
        if color == "green": details.append("✓ No obvious red flags")

    elif etype == "dns":
        details.append(f"Domain: {text}")
        matched = [k for k in ["login","signin","verify","secure","update","banking","paypal","confirm","free","win","prize"] if k in text.lower()]
        if matched:
            verdict, color = "Suspicious", "orange"
            details.append(f"⚠ Suspicious keywords: {', '.join(matched)}")
            tips.append("This domain may be a phishing/scam site")
        if any(s in text.lower() for s in ["google","youtube","github","microsoft","mozilla","wikipedia"]):
            details.append("✓ Well-known trusted domain")
        details.append("ℹ DNS trace — may include private browsing activity")
        if color == "green": details.append("✓ Domain appears normal")

    return {"verdict": verdict, "color": color, "details": details, "tips": tips}

@app.route("/api/analyze", methods=["POST"])
def analyze():
    from flask import request as req
    data = req.get_json()
    return jsonify(analyze_event(data.get("type",""), data.get("text","")))

@app.route("/api/scan/<mode>")
def scan(mode):
    if   mode == "browser": events = get_browser_events()
    elif mode == "file":    events = get_file_events()
    elif mode == "log":     events = get_log_events()
    elif mode == "network": events = get_network_events()
    elif mode == "dns":     events = get_dns_events()
    elif mode == "all":     events = get_browser_events()+get_file_events()+get_log_events()+get_network_events()+get_dns_events()
    else: return jsonify({"error": "Invalid mode"}), 400

    events.sort(key=lambda x: x["time"])
    b, f, l, n, d = save_report(events)

    sus = mal = 0
    for e in events:
        r = analyze_event(e["type"], e["text"])
        e["flag"] = r["color"]; e["verdict"] = r["verdict"]
        if r["color"] == "orange": sus += 1
        elif r["color"] == "red":  mal += 1

    return jsonify({"events": events, "summary": {
        "total":len(events),"browser":b,"file":f,"log":l,"network":n,"dns":d,
        "suspicious":sus,"malicious":mal
    }})

# ---------------------------
# SERVE HTML
# ---------------------------
@app.route("/")
def index():
    return """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Timeline Analyzer</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg:         #0D1117;
      --bg2:        #161B22;
      --bg3:        #1C2333;
      --border:     #30363D;
      --border2:    #21262D;
      --text:       #E6EDF3;
      --text2:      #8B949E;
      --text3:      #484F58;
      --cyan:       #58A6FF;
      --cyan-dim:   #1F3A5F;
      --green:      #3FB950;
      --green-dim:  #12261E;
      --orange:     #D29922;
      --orange-dim: #2D1F00;
      --red:        #F85149;
      --red-dim:    #2D0F0E;
      --purple:     #BC8CFF;
      --yellow:     #E3B341;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'IBM Plex Sans', sans-serif;
      background: var(--bg); color: var(--text);
      min-height: 100vh; padding: 32px 24px;
    }
    .wrap { max-width: 960px; margin: 0 auto; }

    /* HEADER */
    .header {
      display: flex; align-items: center; justify-content: space-between;
      margin-bottom: 32px; padding-bottom: 20px;
      border-bottom: 1px solid var(--border);
    }
    .header-left { display: flex; align-items: center; gap: 14px; }
    .header-icon {
      width: 44px; height: 44px; border-radius: 10px;
      background: var(--cyan-dim); border: 1px solid var(--cyan);
      display: flex; align-items: center; justify-content: center; font-size: 20px;
    }
    .header h1 {
      font-size: 18px; font-weight: 600; color: var(--text);
      font-family: 'IBM Plex Mono', monospace; letter-spacing: -0.02em;
    }
    .header p { font-size: 12px; color: var(--text2); margin-top: 3px; }
    .live-badge {
      font-family: 'IBM Plex Mono', monospace; font-size: 11px;
      padding: 5px 12px; border-radius: 20px;
      background: var(--green-dim); color: var(--green);
      border: 1px solid var(--green); display: flex; align-items: center; gap: 6px;
    }
    .live-dot {
      width: 6px; height: 6px; border-radius: 50%; background: var(--green);
      animation: pulse 2s ease infinite;
    }
    @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.3} }

    /* SECTION LABEL */
    .sec-label {
      font-family: 'IBM Plex Mono', monospace; font-size: 10px;
      letter-spacing: 0.12em; color: var(--text3);
      margin: 28px 0 12px; text-transform: uppercase;
    }

    /* MODE CARDS */
    .mode-grid { display: grid; grid-template-columns: repeat(6,1fr); gap: 8px; }
    .mode-card {
      padding: 16px 10px; border-radius: 10px;
      border: 1px solid var(--border); background: var(--bg2);
      cursor: pointer; text-align: center; transition: all 0.15s; position: relative;
    }
    .mode-card::after {
      content: ''; position: absolute; top: 0; left: 0; right: 0;
      height: 2px; border-radius: 10px 10px 0 0;
      background: var(--cyan); opacity: 0; transition: opacity 0.15s;
    }
    .mode-card:hover, .mode-card.active { border-color: var(--cyan); background: var(--bg3); }
    .mode-card:hover::after, .mode-card.active::after { opacity: 1; }
    .mode-card.active .name { color: var(--cyan); }
    .mode-card.loading { opacity: 0.5; pointer-events: none; }
    .mode-card .icon  { font-size: 22px; margin-bottom: 8px; }
    .mode-card .name  { font-size: 12px; font-weight: 600; color: var(--text); }
    .mode-card .sub   { font-size: 10px; color: var(--text3); margin-top: 3px; font-family:'IBM Plex Mono',monospace; }
    .spinner {
      display: none; position: absolute; top: 8px; right: 8px;
      width: 12px; height: 12px; border: 2px solid var(--border);
      border-top-color: var(--cyan); border-radius: 50%;
      animation: spin 0.6s linear infinite;
    }
    .mode-card.loading .spinner { display: block; }
    @keyframes spin { to { transform: rotate(360deg); } }

    /* STATUS */
    .status-bar {
      margin-top: 10px; padding: 10px 14px; border-radius: 8px;
      font-size: 12px; font-weight: 500; display: none;
      font-family: 'IBM Plex Mono', monospace;
    }
    .status-bar.info    { background:var(--cyan-dim);  color:var(--cyan);  border:1px solid var(--cyan);  display:block; }
    .status-bar.success { background:var(--green-dim); color:var(--green); border:1px solid var(--green); display:block; }
    .status-bar.error   { background:var(--red-dim);   color:var(--red);   border:1px solid var(--red);   display:block; }

    /* STATS */
    .stats-row { display: grid; grid-template-columns: repeat(6,1fr); gap: 8px; }
    .stat-box {
      background: var(--bg2); border: 1px solid var(--border);
      border-radius: 10px; padding: 14px 16px;
    }
    .stat-box .lbl {
      font-size: 9px; color: var(--text3); margin-bottom: 8px;
      letter-spacing: 0.1em; font-family: 'IBM Plex Mono', monospace;
    }
    .stat-box .val { font-size: 28px; font-weight: 600; font-family: 'IBM Plex Mono', monospace; line-height: 1; }
    .v-total   { color: var(--text); }
    .v-browser { color: var(--cyan); }
    .v-file    { color: var(--green); }
    .v-log     { color: var(--orange); }
    .v-network { color: var(--purple); }
    .v-dns     { color: var(--yellow); }

    /* ALERT BOX */
    .alert-box { border-radius: 10px; padding: 12px 16px; margin-bottom: 8px; display: none; }
    .alert-box.has-alerts { display: block; }
    .alert-box.all-safe   { background:var(--green-dim);  border:1px solid var(--green); }
    .alert-box.has-warn   { background:var(--orange-dim); border:1px solid var(--orange); }
    .alert-box.has-danger { background:var(--red-dim);    border:1px solid var(--red); }
    .alert-box-title { font-size: 12px; font-weight: 600; margin-bottom: 10px; font-family:'IBM Plex Mono',monospace; }
    .all-safe  .alert-box-title { color: var(--green); }
    .has-warn  .alert-box-title { color: var(--orange); }
    .has-danger .alert-box-title { color: var(--red); }
    .alert-chips { display: flex; gap: 8px; flex-wrap: wrap; }
    .alert-chip {
      font-size: 11px; font-weight: 600; padding: 4px 12px;
      border-radius: 20px; cursor: pointer; transition: opacity 0.15s;
      font-family: 'IBM Plex Mono', monospace;
    }
    .alert-chip:hover { opacity: 0.75; }
    .chip-red    { background:var(--red-dim);    color:var(--red);    border:1px solid var(--red); }
    .chip-orange { background:var(--orange-dim); color:var(--orange); border:1px solid var(--orange); }
    .chip-green  { background:var(--green-dim);  color:var(--green);  border:1px solid var(--green); }

    /* TIMELINE */
    .timeline-box {
      background: var(--bg2); border: 1px solid var(--border);
      border-radius: 10px; overflow: hidden; margin-top: 8px;
    }
    .tl-top {
      padding: 12px 18px; border-bottom: 1px solid var(--border2);
      display: flex; justify-content: space-between; align-items: center;
      background: var(--bg3);
    }
    .tl-top .tl-title { font-size: 12px; font-weight: 600; color: var(--text); font-family:'IBM Plex Mono',monospace; }
    .tl-top small { font-size: 11px; color: var(--text3); font-family:'IBM Plex Mono',monospace; }

    .event-row {
      display: grid; grid-template-columns: 155px 80px 1fr;
      align-items: center; gap: 12px;
      padding: 10px 18px; border-bottom: 1px solid var(--border2);
      cursor: pointer; transition: background 0.1s;
    }
    .event-row:last-child { border-bottom: none; }
    .event-row:hover { background: var(--bg3); }
    .event-row:hover .etext { color: var(--cyan); }
    .event-row.flag-orange { background:#1A1400; border-left:3px solid var(--orange); }
    .event-row.flag-orange:hover { background:#251D00; }
    .event-row.flag-red    { background:#1A0D0C; border-left:3px solid var(--red); }
    .event-row.flag-red:hover    { background:#2A1210; }

    .etime { font-size:11px; color:var(--text3); font-family:'IBM Plex Mono',monospace; }
    .etag {
      font-size:10px; font-weight:600; padding:3px 8px; border-radius:4px;
      text-align:center; letter-spacing:0.04em; font-family:'IBM Plex Mono',monospace;
    }
    .t-browser { background:var(--cyan-dim);   color:var(--cyan);   border:1px solid var(--cyan); }
    .t-file    { background:var(--green-dim);  color:var(--green);  border:1px solid var(--green); }
    .t-log     { background:var(--orange-dim); color:var(--orange); border:1px solid var(--orange); }
    .t-network { background:#1A0F2E; color:var(--purple); border:1px solid var(--purple); }
    .t-dns     { background:#1F1700; color:var(--yellow); border:1px solid var(--yellow); }

    .etext {
      font-size:11px; color:var(--text2); font-family:'IBM Plex Mono',monospace;
      white-space:nowrap; overflow:hidden; text-overflow:ellipsis; transition:color 0.1s;
    }
    .flag-dot { width:6px; height:6px; border-radius:50%; display:inline-block; margin-right:5px; }
    .dot-red    { background: var(--red); }
    .dot-orange { background: var(--orange); }
    .empty { padding:40px; text-align:center; font-size:12px; color:var(--text3); font-family:'IBM Plex Mono',monospace; }

    /* BOTTOM */
    .bottom-row { display:flex; justify-content:flex-end; margin-top:16px; }
    .dl-btn {
      padding:9px 20px; border-radius:8px; border:1px solid var(--border);
      background:var(--bg2); font-size:12px; font-weight:500; color:var(--text2);
      cursor:pointer; font-family:'IBM Plex Sans',sans-serif; transition:all 0.15s;
    }
    .dl-btn:hover { border-color:var(--cyan); color:var(--cyan); background:var(--bg3); }

    /* MODAL */
    .modal-overlay {
      display:none; position:fixed; inset:0;
      background:rgba(0,0,0,0.75); z-index:100;
      align-items:center; justify-content:center; backdrop-filter:blur(3px);
    }
    .modal-overlay.open { display:flex; }
    .modal {
      background:var(--bg2); border-radius:14px; width:500px; max-width:95vw;
      border:1px solid var(--border); box-shadow:0 24px 80px rgba(0,0,0,0.7); overflow:hidden;
    }
    .modal-header {
      padding:16px 20px; display:flex; align-items:center; justify-content:space-between;
      border-bottom:1px solid var(--border2);
    }
    .modal-header.green  { background:var(--green-dim); }
    .modal-header.orange { background:var(--orange-dim); }
    .modal-header.red    { background:var(--red-dim); }
    .verdict-badge { font-size:12px; font-weight:700; padding:4px 14px; border-radius:20px; font-family:'IBM Plex Mono',monospace; }
    .badge-green  { background:var(--green-dim);  color:var(--green);  border:1px solid var(--green); }
    .badge-orange { background:var(--orange-dim); color:var(--orange); border:1px solid var(--orange); }
    .badge-red    { background:var(--red-dim);    color:var(--red);    border:1px solid var(--red); }
    .modal-close  { font-size:18px; cursor:pointer; color:var(--text3); background:none; border:none; transition:color 0.1s; }
    .modal-close:hover { color:var(--text); }
    .modal-body   { padding:18px 20px; }
    .modal-meta   { font-size:10px; letter-spacing:0.08em; color:var(--text3); margin-bottom:10px; font-family:'IBM Plex Mono',monospace; }
    .modal-text   {
      font-size:11px; color:var(--text2); font-family:'IBM Plex Mono',monospace;
      background:var(--bg3); padding:10px 12px; border-radius:6px;
      word-break:break-all; margin-bottom:14px; border:1px solid var(--border2); line-height:1.5;
    }
    .detail-list { list-style:none; margin-bottom:14px; }
    .detail-list li { font-size:12px; color:var(--text2); padding:6px 0; border-bottom:1px solid var(--border2); }
    .detail-list li:last-child { border-bottom:none; }
    .tips-box { background:var(--cyan-dim); border-radius:8px; padding:10px 14px; border:1px solid var(--cyan); }
    .tips-label { font-size:10px; font-weight:600; color:var(--cyan); margin-bottom:6px; letter-spacing:0.08em; font-family:'IBM Plex Mono',monospace; }
    .tips-box li { font-size:12px; color:var(--text2); padding:3px 0; list-style:disc; margin-left:16px; }
    .modal-loading { padding:48px; text-align:center; font-size:12px; color:var(--text3); font-family:'IBM Plex Mono',monospace; }
  </style>
</head>
<body>
<div class="wrap">

  <div class="header">
    <div class="header-left">
      <div class="header-icon">&#128269;</div>
      <div>
        <h1>timeline_analyzer</h1>
        <p>Digital Forensics &amp; Activity Monitor — Kali Linux</p>
      </div>
    </div>
    <span class="live-badge"><span class="live-dot"></span>LIVE</span>
  </div>

  <div class="sec-label">// scan_mode</div>
  <div class="mode-grid">
    <div class="mode-card" id="m1" onclick="runScan('browser',1)">
      <div class="spinner"></div>
      <div class="icon">&#127758;</div>
      <div class="name">Browser</div>
      <div class="sub">chrome history</div>
    </div>
    <div class="mode-card" id="m2" onclick="runScan('file',2)">
      <div class="spinner"></div>
      <div class="icon">&#128193;</div>
      <div class="name">Files</div>
      <div class="sub">.txt files</div>
    </div>
    <div class="mode-card" id="m3" onclick="runScan('log',3)">
      <div class="spinner"></div>
      <div class="icon">&#128220;</div>
      <div class="name">Logs</div>
      <div class="sub">journald</div>
    </div>
    <div class="mode-card" id="m4" onclick="runScan('network',4)">
      <div class="spinner"></div>
      <div class="icon">&#127760;</div>
      <div class="name">Network</div>
      <div class="sub">tcp connections</div>
    </div>
    <div class="mode-card" id="m5" onclick="runScan('dns',5)">
      <div class="spinner"></div>
      <div class="icon">&#128270;</div>
      <div class="name">DNS</div>
      <div class="sub">private traces</div>
    </div>
    <div class="mode-card" id="m6" onclick="runScan('all',6)">
      <div class="spinner"></div>
      <div class="icon">&#128200;</div>
      <div class="name">All Sources</div>
      <div class="sub">full scan</div>
    </div>
  </div>

  <div class="status-bar" id="status"></div>

  <div class="sec-label">// results</div>
  <div class="stats-row">
    <div class="stat-box"><div class="lbl">TOTAL</div>  <div class="val v-total"   id="st">—</div></div>
    <div class="stat-box"><div class="lbl">BROWSER</div><div class="val v-browser" id="sb">—</div></div>
    <div class="stat-box"><div class="lbl">FILES</div>  <div class="val v-file"    id="sf">—</div></div>
    <div class="stat-box"><div class="lbl">LOGS</div>   <div class="val v-log"     id="sl">—</div></div>
    <div class="stat-box"><div class="lbl">NETWORK</div><div class="val v-network" id="sn">—</div></div>
    <div class="stat-box"><div class="lbl">DNS</div>    <div class="val v-dns"     id="sd">—</div></div>
  </div>

  <div class="sec-label">// timeline</div>

  <div class="alert-box" id="alert-box">
    <div class="alert-box-title" id="alert-title"></div>
    <div class="alert-chips" id="alert-chips"></div>
  </div>

  <div class="timeline-box">
    <div class="tl-top">
      <span class="tl-title" id="tl-title">activity_log</span>
      <small id="tl-count">select a mode to begin</small>
    </div>
    <div id="tl">
      <div class="empty">_ click any mode card above to start scanning</div>
    </div>
  </div>

  <div class="bottom-row">
    <button class="dl-btn" onclick="downloadReport()">&#8659;&nbsp; Export report.txt</button>
  </div>

</div>

<!-- MODAL -->
<div class="modal-overlay" id="modal-overlay" onclick="closeModal(event)">
  <div class="modal">
    <div class="modal-loading" id="modal-loading">_ analyzing_event...</div>
    <div id="modal-content" style="display:none">
      <div class="modal-header" id="modal-header">
        <div>
          <div style="font-size:10px;color:var(--text3);margin-bottom:6px;font-family:'IBM Plex Mono',monospace;letter-spacing:0.08em" id="modal-type-label">EVENT_TYPE</div>
          <span class="verdict-badge" id="modal-badge">Safe</span>
        </div>
        <button class="modal-close" onclick="closeModal()">&#10005;</button>
      </div>
      <div class="modal-body">
        <div class="modal-meta" id="modal-type-top"></div>
        <div class="modal-text" id="modal-text-val"></div>
        <ul class="detail-list" id="modal-details"></ul>
        <div class="tips-box" id="modal-tips" style="display:none">
          <div class="tips-label">&#9888; RECOMMENDATIONS</div>
          <ul id="modal-tips-list"></ul>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  let lastEvents=[], displayedEvents=[], isScanning=false;

  async function runScan(mode, n) {
    if (isScanning) return;
    isScanning = true;
    [1,2,3,4,5,6].forEach(i => document.getElementById('m'+i).classList.remove('active','loading'));
    const card = document.getElementById('m'+n);
    card.classList.add('active','loading');
    const labels = {browser:'Browser History',file:'File Events',log:'Log Events',
                    network:'Network Connections',dns:'DNS History',all:'Full Scan'};
    setStatus('info','> scanning ' + labels[mode] + '...');
    document.getElementById('tl-title').textContent = labels[mode].toLowerCase().replaceAll(' ','_');
    document.getElementById('tl-count').textContent = 'scanning...';
    document.getElementById('tl').innerHTML = '<div class="empty">_ scanning in progress...</div>';
    try {
      const res = await fetch('/api/scan/'+mode);
      if (!res.ok) throw new Error();
      const data = await res.json();
      lastEvents = data.events;
      document.getElementById('st').textContent = data.summary.total;
      document.getElementById('sb').textContent = data.summary.browser;
      document.getElementById('sf').textContent = data.summary.file;
      document.getElementById('sl').textContent = data.summary.log;
      document.getElementById('sn').textContent = data.summary.network ?? 0;
      document.getElementById('sd').textContent = data.summary.dns ?? 0;
      renderTimeline(data.events);
      document.getElementById('tl-count').textContent = data.events.length + ' events found';
      showAlertSummary(data.summary);
      setStatus('success','> done. ' + data.summary.total + ' events loaded. report.txt saved.');
    } catch {
      setStatus('error','> error: could not connect. check terminal.');
      document.getElementById('tl').innerHTML = '<div class="empty">_ error loading data</div>';
    }
    card.classList.remove('loading');
    isScanning = false;
  }

  function renderTimeline(events) {
    displayedEvents = events;
    const c = document.getElementById('tl');
    if (!events || !events.length) {
      c.innerHTML = '<div class="empty">_ no events found for this mode</div>';
      return;
    }
    c.innerHTML = events.map((e,i) => {
      const fc = e.flag && e.flag!=='green' ? 'flag-'+e.flag : '';
      const dot = e.flag==='red' ? '<span class="flag-dot dot-red"></span>'
                : e.flag==='orange' ? '<span class="flag-dot dot-orange"></span>' : '';
      return `<div class="event-row ${fc}" onclick="showDetail(${i})" title="Click for analysis">
        <span class="etime">${e.time}</span>
        <span class="etag t-${e.type}">[${e.type.toUpperCase()}]</span>
        <span class="etext">${dot}${e.text}</span>
      </div>`;
    }).join('');
  }

  function showAlertSummary(s) {
    const box=document.getElementById('alert-box'),title=document.getElementById('alert-title'),chips=document.getElementById('alert-chips');
    const mal=s.malicious||0,sus=s.suspicious||0,safe=s.total-mal-sus;
    chips.innerHTML='';
    if (!mal&&!sus) {
      box.className='alert-box has-alerts all-safe';
      title.textContent='✓ all_events_safe — no threats detected';
      chips.innerHTML=`<span class="alert-chip chip-green">✓ ${safe} safe</span>`;
    } else {
      box.className='alert-box has-alerts '+(mal>0?'has-danger':'has-warn');
      title.textContent=mal>0?`! ${mal} malicious + ${sus} suspicious — click highlighted rows`:`! ${sus} suspicious events — click rows for details`;
      if(mal) chips.innerHTML+=`<span class="alert-chip chip-red" onclick="filterEvents('red')">! ${mal} malicious</span>`;
      if(sus) chips.innerHTML+=`<span class="alert-chip chip-orange" onclick="filterEvents('orange')">~ ${sus} suspicious</span>`;
      if(safe) chips.innerHTML+=`<span class="alert-chip chip-green" onclick="filterEvents('green')">✓ ${safe} safe</span>`;
    }
  }

  function filterEvents(flag) {
    const f=flag==='all'?lastEvents:lastEvents.filter(e=>flag==='green'?(!e.flag||e.flag==='green'):e.flag===flag);
    renderTimeline(f);
    document.getElementById('tl-count').textContent=f.length+' events shown';
  }

  async function showDetail(i) {
    const e=displayedEvents[i];
    const overlay=document.getElementById('modal-overlay'),loading=document.getElementById('modal-loading'),mc=document.getElementById('modal-content');
    overlay.classList.add('open');
    loading.style.display='block'; mc.style.display='none';
    try {
      const res=await fetch('/api/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:e.type,text:e.text})});
      const data=await res.json();
      const bm={green:'badge-green',orange:'badge-orange',red:'badge-red'};
      const ic={green:'✓ Safe',orange:'⚠ Suspicious',red:'✕ Malicious'};
      const c=data.color;
      document.getElementById('modal-header').className='modal-header '+c;
      document.getElementById('modal-badge').className='verdict-badge '+bm[c];
      document.getElementById('modal-badge').textContent=ic[c];
      document.getElementById('modal-type-label').textContent=e.type.toUpperCase()+'_EVENT';
      document.getElementById('modal-type-top').textContent='scanned_at: '+e.time;
      document.getElementById('modal-text-val').textContent=e.text;
      document.getElementById('modal-details').innerHTML=data.details.map(d=>`<li>${d}</li>`).join('');
      const tb=document.getElementById('modal-tips'),tl=document.getElementById('modal-tips-list');
      if(data.tips&&data.tips.length){tl.innerHTML=data.tips.map(t=>`<li>${t}</li>`).join('');tb.style.display='block';}
      else tb.style.display='none';
      loading.style.display='none'; mc.style.display='block';
    } catch { loading.textContent='_ error loading analysis'; }
  }

  function closeModal(e) {
    if(!e||e.target===document.getElementById('modal-overlay'))
      document.getElementById('modal-overlay').classList.remove('open');
  }

  function setStatus(type,msg) {
    const bar=document.getElementById('status');
    bar.className='status-bar '+type; bar.textContent=msg;
  }

  function downloadReport() {
    if(!lastEvents.length){alert('Run a scan first.');return;}
    let text='=== Digital Activity Timeline ===\\n\\n';
    lastEvents.forEach(e=>{text+=`${e.time} -> [${e.type.toUpperCase()}] ${e.text}\\n`;});
    const cnt=t=>lastEvents.filter(e=>e.type===t).length;
    text+=`\\n--- Summary ---\\nTotal: ${lastEvents.length}\\nBrowser: ${cnt('browser')}\\nFile: ${cnt('file')}\\nLogs: ${cnt('log')}\\nNetwork: ${cnt('network')}\\nDNS: ${cnt('dns')}\\n`;
    const a=document.createElement('a');
    a.href=URL.createObjectURL(new Blob([text],{type:'text/plain'}));
    a.download='report.txt'; a.click();
  }
</script>
</body>
</html>"""

# ---------------------------
# MAIN
# ---------------------------
if __name__ == "__main__":
    print("[+] Starting Timeline Analyzer...")
    print("[+] Opening browser at http://localhost:5000\n")
    threading.Timer(1.0, lambda: webbrowser.open("http://localhost:5000")).start()
    app.run(debug=False, port=5000)