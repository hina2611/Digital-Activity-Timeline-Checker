import base64 as _b, zlib as _z, types as _t

# ---------------------------------------------------------------
# Digital Activity Timeline Analyzer
# Obfuscated build — do not modify this file directly
# ---------------------------------------------------------------

_c = "eNrtW91y47iVvvdTYJHqaiqWKP90ezba0cy6u9XTrnXbLkvpqYlaUVEkKHFEkRwCtFrjUSoX+wa7V6mt2r3cV8jr5AnyCDkHAMVfWbITV+3FaqYtEgQODs75zg8OKG8RhbEgIT/w1BX/yfcEO93czhLh+endkk0mcbjkLE5bxCxmluMF0wM3DhfEsQQT3oIR/Ti9bxL86zBfWKqj61t8nvZ6jzdN8iMPA89dHRxYUUS6qtUYjwNrwcbjxsHBr0hr+weevr2+en/x3Y5uM4+LMF6NI0vMYJKQm3hlsi+RFTgJrMygf2ibdhi43rQ9DcOpz1r2DFhm7XfMtRJftD8oErRxINgiGjsToEN1o+lM6G5OBxcfe8jup95t/+L6akd/h7kEGLpjsRgrVsYoTSN33egcEPiIeKUu8BMzkcTBRgXG8dnRcZPg/w1ymOnDWHh2HHIGMzi8m6cpKbEvNotEhepVGLDd6zw2yZvb6+/7vVvS+9S7GvT3WOmUibEG2ZjdsUBwQ69O3YGwhyN577kkCEVOhaACbuQV3KjwrWhUhaVwDnqPVicFEoBcpeTGpi9IKoCvbmoriJaA2cKo9kxiHsbQE3uY6s4oPwbGmZ0IZtB+77L3dkCS2G8SAL8Y33ncE1IZ5P3t9Ud8wsn17TuQ55sfKl3e9fpvaUbdhZklKUG8IJ3LZcKeWb5v5EQjhYEEurUwE41CT5A6NheHZ+oxwXhZ4Bj3FHvRjuxschG7khh98UPrxaL1wiEvPnRefOy86NNGk1CxirAv1Yqn2MS+CGiCFayLojdtH+Bq1MMzsrjSblHfO5F6YpL3F5e9x8HU9Xy2A6OohInFmfI3oIchbc9AtLjCNuhCft9ZcdsPp3TUKSgvDkPRJI4X8ybBqTiOB7QvLX9ubIiWFIkDsTP2lYOqigIN4hMT1MSXnpgZ1BQg60a1Z8VMyp+SF/0x9AJDsY0zNLaOE0QaUDoOhLmQ8JAL2jpqC8JSD2diZMELLqxFBLjdAbut85Q+G3TimnLQRGbX9dyWYVmV29NgemqSy+vvHodSQFYJpGlsTyZRHNpMs1KGbimYcAh96PM2g8w4CYwh/TGEBVi+LXwUTSvAv6+P5HUrCFuRNVX23GqFiYgS0eUzmJyOiuK3rQgEwca6zyBOMGcAOaeXoEV41n1d9G++F0ikK/ZA3w50MnkEfhkf8bKbk/278gvB4UVGxblhSJHdNHnoZ8VCG0qrVWcm4JWEFyTsYKfdREhqwwCyaVQBhGLeYBq4jCSEXXpydHJG7iWJ4dFonV4eZ5cnozWK+sUP5MWEFMBenQRojt0FziUetpODfYCdI7dhPQiXRuMxtLcHECSdCxPoLDM7pEONQWdEKKQ2KNxh5/g1yGhHkJAQAvNIHeYQKUtn2Nx45bYTzaemnDFrs3zBYEbh3TGuntWbejZiAl4RRGFFFVIJOMBSG1/xUjwAYJbynJTvciCvgx2Cl4Qg1s0okB5aJYvjMOZd6k2DMGa0QSxO3Hq3lTc318SsX1vYsHV61Blt93W7bK5kf9iv86Br3hUG9sDd3r6/4P+LsHPp8D7VCUZj3KdkWlmPyH0OiHS9nx09NTC8MslVb/D99e2/PS44BEwsw3j+pAABcn6Kue8ZVziXUUMEEcSK54sPw+Mydh8RI/YMBTu9/hZEg0RzTk+rqsbV5BGZhgdkU83LfM7Iy5cISPXwVD70wRvI+8Y3p5s+pPVN2utVuderrBfRqurqvq/LfV/rvkkwh0UELzf43+qKtVSVJLLnFXeWuTLaRi7aIJa2sCMqPdo2B7bdeR1vc11FpSkcbA3Zqe/aSIB8TV5t92K1KEk/aJoz9mUswjHMOWtsJ+NFTSINtUtmmjXaodu9q/Yp1KQqU4dVGV4gDC8aeh3v8GTUPD5rNKSwPJSUcdZ81TxpHjWwYODSzj12xgmx35rWzgPZkkDzuadHx8BMrz84f3N50f/QewcB7ugcmuBu0LvCuzO4w1LI+PvziwFd4zbASCFqJmAMsFlukrRlS6b995lOrbvPrEmuBi0nU0iadDWUsZQfnMCDvLOvc/RPdfKvTfLuqv84B+8EfJdzbwIf//gdwLNtAf65kfMeAvMwYCpmph0uIoi8RoFoTI1vOz8lLF79AgsI/Tvm/OKH4TyJfgHJpG2N4e8/B6Nff2sMrdbP563fHbV+Mxq2sutfA5HP5raHjcNGCVnAzcV3V9e3vbfn/V7GLmcMeeUs70Keso3RztIKVsZ8iQOlk/LDJVqMpKiahxQWCZYmBQDfarlwoUQAF8EXJ1xYXkBH/7+vea59zQIGa6SanFmxPTNQTpWsYlGdXikHxi/MaRwmkXHcSNVcV9ZBQMgqkR6HSODpxsa2/FnIhdQ+XMO3FUcWfIFXx80MtjihPUdbpfNkAm1MMF6LjAeDGDCi50eQwhfivp4GPjEtxzHUgEe5+Jp9oUR73oGDuwTnrYhD2mJwcFU26xDtsho705IC2vO5BxN2G8XJtycehaSjuv599kW76hG/oo9Vzl6WWkxlvumSk+17QhQCrlAb7UM7QSAre2tYGFVQ4vUZQjI6a+Ufqvswmlj2nlFchXIcZ/l+EDqMazJwC5YEiOeotMDBdAi5wZn+j+47K7D+cN0fILCRZ4A15CE5/7kT04/MOs5M0j//1CO3vZvr28EeaQe37tg4ZphlGGoSDVI7TFR+cS86kEYsjGOJIGkgOvcAiLChWvio2xUqmAnlwjaHA7oQq/bjWXIn5TRaH5RMVXGiqjqELium6prL2MPjl263S955U09YPjm3hXfniRUZgCqVpXa7n4PPQemAJcd7yfg1VZfes+FLBMTLkcwYh/IeFvhyk+NigomNoF/oVJwjZe5zAOIl/WSxsOIVqqDCyrx5Jw96pJBNGLSo5A05puYm5Fu4VO9nBt2+Pj5Zd8j9Xf3sLh2EKBX9gY7oHrRusyEaWIqDTF+4fddNUnG5e1nlym5TVeaapE53g/Qrk5xfnV/+8Dt9hLMHTC0IAKuf9QGOwVAlKt8s5sk6N75jsePZAhnzw7gJuzRheT7HtDRCSNO+5crDgWkMMQ0uhiP8d5BubiV9AFF2xpWpRtNKPYtLf3t7CTJGXtY5beDJGzQVAsBMiKjTbpfDQJFbyV7CI8/2wkS6kjC2gikr7uBKXNC//Ol/8Ji39WEwuOkTfcbpheC3k4AFdryKBHMapVwHpbGhcBMzl0GEAB45MKnSERZwD+umxNImlqOARYPOw0z913+QKkO17FQS1U0yBem56wUOHoPGUoL8W2DPGP6+PcJUXoEAXOlDnLj0nSTX2aQX5azPEvaMObibmiv73FSYId1uUu5NA3lh2RLrcAVa81zM0zmzYScEF0mE0QUuJlYw9wJ0d5G1imSuJt9RiBdU1l7mWdaXJoijSn6pOKoGuaegpVYkCJlsKJmzFZizw0FGL5vkpSo6aC4a69rkPYeeT1IaRMw8TgAyjEwYiJERhukqyILYMXPgxrN8TivJdCkVLmyOdEqs3u4ASYLLnyUTlLuA/CIEcbjQHe4X4c+e72OOHK3ELERtqbclQhf1tfTmXsQcDzusIKeAnLk2W64D8ffM91uyOAZATThgV3NK96wd6HUClqVE80j+7Bx+Ngt/aMGzbdf7R4gHG7WDeB/2EH/97z/9L0TMGMyQXNwQyONhg8kJeC/ylz/+J5l505m/gkC/wdIDvuJdqOp/qNy8ZgnY98VNCwvsDlJGIiq98QteVUaWB1zqjSVmNT614iSw4qOPpvHSkGIrGrZ+V2LLsTOOgqFj2fSYbaK1H13rsXS1KMgheCKX9iHegxxSahxu12Sywo1eE1LLSwvy84+h47keeApyLxlYZ4/ObSz8yEeWejR6EK5lyLxXJ21uiAHed6TOJ4xgRbYY6dB+y9EuUuYb6fcoxAIrGG2H3bX5bJGen2Hr6JnCoeZevhIEY+JV+y70QQ7Q6kgzUK+FbQX5+/QtDuSSWODMwJGwgCQI7skKPLS/tPAcrhzz9Ypx04kOYOngavGOzyxHuip1lzghbmyahf2pugG3FQhrQkfP4APeQpbowW6N8BV4soV6AcXSUGkvNJz+6SHR5L29GmBbMrgvIVvHM9IwBqg6demQKnxDDjRsHY8K2ZH5XHnRB88BB6XWaagZ1ZbDCcWDKVFuICe2hclyYDOQ3CKVel1e5Lkpw900wdydJkmwyhd0sNWKORhbDNNscaCYij/gP2+tJR6V17lQH2ttqIlyZQroUxfIgNqk1fhYw5AtmN2opufRzzkABgOIxpCeEruCkRZQVNHQx8SHexCdHgRwtFbAq4PEIAmJE8Fa4IZsQLjAfKGQv+KSQcFecclJkEPwfut+ghX+NjeLtj5kEXyV2Gvlb2fMnpPlzLNn6JHiNsR0EXvTKYP5pWVWlirfH3hWTfaVR5ETyUo3wLTMBbq9vLjxDbRnZeomBgv12RTEYoewIw8c8ALARBtnblTZfNDbSQcXkLzunAWQsOTm5tG7o8twillUvNqYPZa7vIBtsft0z/2A7b/dbLUeZf4yVuNpIVnwKQrlnr6CD+3QjzADuO3QQ2DKl6oJIhhC1fHp6VfQ4Q3YlRPq8emzU/2w58vdQNpFPX2gsEbP4APjLm7ftiehgAUTUCIQhOav6tpPTvFgkvnYktvrpk/xXPP94KbyaF1fdMHXLWnnHleyVqgEYW3dhBVtX7pQuUAciGKU5+p52Nac2iC2MYeVfmMbib03dTeoAsU+JoR8umvn5tKL4A6yVm+KDlOfFWIeH2WUiLdY4M5JMH9VQ24CCeG8EEcwC574Hp9lHrSKf1m1g6QqERPYUjttL5DfuVpBxXcAScjAMpI1VtVn8Z0H7l51xZ0nIjujWXWL8mhiaXliO6uZTRF8nxmpGpuz8EYx9tMjU/63BT11HuqNXLcIieX7RB7wuBaogRiaVGN3IMD8Su699fL5TGbskK1HCWjChq2dCjLexGfVDXglYXm0960lUufyrkISTu5k8oSRyvWt6bZtIpYTH/B0m5pO2cvtXc15Wg2nSV1YnywpIJEI40CusJN3r6ODXSWdf0CU+/tKOQUwDRBDuvSGmRTgxyIRNM5AFm1uWwtZ3anu/nh55bW1m7Tukqvi5Es0WQUnK9aUd4dPLc9Uxv37n+X7GSIGU5MVEJU52n7ioB/07lQCGS6lue+Z59eyp3C6JbHXZfh7qoGQNz0q6UOLLmNTTT2bBw+aQH/ygDXi64ODf4VZTHlkBpssK/LaunAOUFowyFkc3h3Sm+v+AASbL6yncbD6e6+Y/ZSAP8dzGLiUncBELFmZ/QnfAhrjT8GMwqGC/nGYUaza4zD52pA6MmpS/DVJrpHJV3lpo9GoWQdgL2h/DZtN9g1VnGOLgQ3pEYCLpg/3xcJ99qJM3Y+VMrezGamKU4VXbCq/H6kZJrdkpDIs/0J/zahNQlccVX7Ts2akdI7V+fKvENWMgghTN6oslsPKig/Lizms4/NwCwuQC5exca/3Ix2CGQgkUY7kkq4BFK+Ojg5yLzmZHE8nwat1fWsxcSzypUO+DNWRrn7TbNIkbpP4TRIApPC1neqxpqLIE1wzGCD8PTp48GQQvXHp3Ck97WzKg08EbO5NN2jCaAahAGxjqI139C/Ynhq3frS5LRSHN0OkprTj70iOD7vkuJi2lHpj8tghcl2yb501gsTlCjdga+JuTJ5RQtP9QXaUjeeHtJM7Nmxm9jTRJ7odV53pdvzsVLcTqHPdjpOl+DRXUu7ANbj5TcbcgUvZcb3e4yej/d7tpx75MPh4uaPr3wB0jPZl"

_m = _t.ModuleType("_core")
exec(compile(_z.decompress(_b.b64decode(_c)), "<core>", "exec"), _m.__dict__)

# Flask app reference for routing
import sys as _s
_s.modules[__name__].__dict__.update({
    k: v for k, v in _m.__dict__.items()
    if not k.startswith("__")
})

@app.route("/")
def index():
    return """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Timeline Analyzer</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg:         #0D1117;
      --bg2:        #161B22;
      --bg3:        #1C2333;
      --border:     #30363D;
      --border2:    #21262D;
      --text:       #E6EDF3;
      --text2:      #8B949E;
      --text3:      #484F58;
      --cyan:       #58A6FF;
      --cyan-dim:   #1F3A5F;
      --green:      #3FB950;
      --green-dim:  #12261E;
      --orange:     #D29922;
      --orange-dim: #2D1F00;
      --red:        #F85149;
      --red-dim:    #2D0F0E;
      --purple:     #BC8CFF;
      --yellow:     #E3B341;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'IBM Plex Sans', sans-serif;
      background: var(--bg); color: var(--text);
      min-height: 100vh; padding: 32px 24px;
    }
    .wrap { max-width: 960px; margin: 0 auto; }

    /* HEADER */
    .header {
      display: flex; align-items: center; justify-content: space-between;
      margin-bottom: 32px; padding-bottom: 20px;
      border-bottom: 1px solid var(--border);
    }
    .header-left { display: flex; align-items: center; gap: 14px; }
    .header-icon {
      width: 44px; height: 44px; border-radius: 10px;
      background: var(--cyan-dim); border: 1px solid var(--cyan);
      display: flex; align-items: center; justify-content: center; font-size: 20px;
    }
    .header h1 {
      font-size: 18px; font-weight: 600; color: var(--text);
      font-family: 'IBM Plex Mono', monospace; letter-spacing: -0.02em;
    }
    .header p { font-size: 12px; color: var(--text2); margin-top: 3px; }
    .live-badge {
      font-family: 'IBM Plex Mono', monospace; font-size: 11px;
      padding: 5px 12px; border-radius: 20px;
      background: var(--green-dim); color: var(--green);
      border: 1px solid var(--green); display: flex; align-items: center; gap: 6px;
    }
    .live-dot {
      width: 6px; height: 6px; border-radius: 50%; background: var(--green);
      animation: pulse 2s ease infinite;
    }
    @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.3} }

    /* SECTION LABEL */
    .sec-label {
      font-family: 'IBM Plex Mono', monospace; font-size: 10px;
      letter-spacing: 0.12em; color: var(--text3);
      margin: 28px 0 12px; text-transform: uppercase;
    }

    /* MODE CARDS */
    .mode-grid { display: grid; grid-template-columns: repeat(6,1fr); gap: 8px; }
    .mode-card {
      padding: 16px 10px; border-radius: 10px;
      border: 1px solid var(--border); background: var(--bg2);
      cursor: pointer; text-align: center; transition: all 0.15s; position: relative;
    }
    .mode-card::after {
      content: ''; position: absolute; top: 0; left: 0; right: 0;
      height: 2px; border-radius: 10px 10px 0 0;
      background: var(--cyan); opacity: 0; transition: opacity 0.15s;
    }
    .mode-card:hover, .mode-card.active { border-color: var(--cyan); background: var(--bg3); }
    .mode-card:hover::after, .mode-card.active::after { opacity: 1; }
    .mode-card.active .name { color: var(--cyan); }
    .mode-card.loading { opacity: 0.5; pointer-events: none; }
    .mode-card .icon  { font-size: 22px; margin-bottom: 8px; }
    .mode-card .name  { font-size: 12px; font-weight: 600; color: var(--text); }
    .mode-card .sub   { font-size: 10px; color: var(--text3); margin-top: 3px; font-family:'IBM Plex Mono',monospace; }
    .spinner {
      display: none; position: absolute; top: 8px; right: 8px;
      width: 12px; height: 12px; border: 2px solid var(--border);
      border-top-color: var(--cyan); border-radius: 50%;
      animation: spin 0.6s linear infinite;
    }
    .mode-card.loading .spinner { display: block; }
    @keyframes spin { to { transform: rotate(360deg); } }

    /* STATUS */
    .status-bar {
      margin-top: 10px; padding: 10px 14px; border-radius: 8px;
      font-size: 12px; font-weight: 500; display: none;
      font-family: 'IBM Plex Mono', monospace;
    }
    .status-bar.info    { background:var(--cyan-dim);  color:var(--cyan);  border:1px solid var(--cyan);  display:block; }
    .status-bar.success { background:var(--green-dim); color:var(--green); border:1px solid var(--green); display:block; }
    .status-bar.error   { background:var(--red-dim);   color:var(--red);   border:1px solid var(--red);   display:block; }

    /* STATS */
    .stats-row { display: grid; grid-template-columns: repeat(6,1fr); gap: 8px; }
    .stat-box {
      background: var(--bg2); border: 1px solid var(--border);
      border-radius: 10px; padding: 14px 16px;
    }
    .stat-box .lbl {
      font-size: 9px; color: var(--text3); margin-bottom: 8px;
      letter-spacing: 0.1em; font-family: 'IBM Plex Mono', monospace;
    }
    .stat-box .val { font-size: 28px; font-weight: 600; font-family: 'IBM Plex Mono', monospace; line-height: 1; }
    .v-total   { color: var(--text); }
    .v-browser { color: var(--cyan); }
    .v-file    { color: var(--green); }
    .v-log     { color: var(--orange); }
    .v-network { color: var(--purple); }
    .v-dns     { color: var(--yellow); }

    /* ALERT BOX */
    .alert-box { border-radius: 10px; padding: 12px 16px; margin-bottom: 8px; display: none; }
    .alert-box.has-alerts { display: block; }
    .alert-box.all-safe   { background:var(--green-dim);  border:1px solid var(--green); }
    .alert-box.has-warn   { background:var(--orange-dim); border:1px solid var(--orange); }
    .alert-box.has-danger { background:var(--red-dim);    border:1px solid var(--red); }
    .alert-box-title { font-size: 12px; font-weight: 600; margin-bottom: 10px; font-family:'IBM Plex Mono',monospace; }
    .all-safe  .alert-box-title { color: var(--green); }
    .has-warn  .alert-box-title { color: var(--orange); }
    .has-danger .alert-box-title { color: var(--red); }
    .alert-chips { display: flex; gap: 8px; flex-wrap: wrap; }
    .alert-chip {
      font-size: 11px; font-weight: 600; padding: 4px 12px;
      border-radius: 20px; cursor: pointer; transition: opacity 0.15s;
      font-family: 'IBM Plex Mono', monospace;
    }
    .alert-chip:hover { opacity: 0.75; }
    .chip-red    { background:var(--red-dim);    color:var(--red);    border:1px solid var(--red); }
    .chip-orange { background:var(--orange-dim); color:var(--orange); border:1px solid var(--orange); }
    .chip-green  { background:var(--green-dim);  color:var(--green);  border:1px solid var(--green); }

    /* TIMELINE */
    .timeline-box {
      background: var(--bg2); border: 1px solid var(--border);
      border-radius: 10px; overflow: hidden; margin-top: 8px;
    }
    .tl-top {
      padding: 12px 18px; border-bottom: 1px solid var(--border2);
      display: flex; justify-content: space-between; align-items: center;
      background: var(--bg3);
    }
    .tl-top .tl-title { font-size: 12px; font-weight: 600; color: var(--text); font-family:'IBM Plex Mono',monospace; }
    .tl-top small { font-size: 11px; color: var(--text3); font-family:'IBM Plex Mono',monospace; }

    .event-row {
      display: grid; grid-template-columns: 155px 80px 1fr;
      align-items: center; gap: 12px;
      padding: 10px 18px; border-bottom: 1px solid var(--border2);
      cursor: pointer; transition: background 0.1s;
    }
    .event-row:last-child { border-bottom: none; }
    .event-row:hover { background: var(--bg3); }
    .event-row:hover .etext { color: var(--cyan); }
    .event-row.flag-orange { background:#1A1400; border-left:3px solid var(--orange); }
    .event-row.flag-orange:hover { background:#251D00; }
    .event-row.flag-red    { background:#1A0D0C; border-left:3px solid var(--red); }
    .event-row.flag-red:hover    { background:#2A1210; }

    .etime { font-size:11px; color:var(--text3); font-family:'IBM Plex Mono',monospace; }
    .etag {
      font-size:10px; font-weight:600; padding:3px 8px; border-radius:4px;
      text-align:center; letter-spacing:0.04em; font-family:'IBM Plex Mono',monospace;
    }
    .t-browser { background:var(--cyan-dim);   color:var(--cyan);   border:1px solid var(--cyan); }
    .t-file    { background:var(--green-dim);  color:var(--green);  border:1px solid var(--green); }
    .t-log     { background:var(--orange-dim); color:var(--orange); border:1px solid var(--orange); }
    .t-network { background:#1A0F2E; color:var(--purple); border:1px solid var(--purple); }
    .t-dns     { background:#1F1700; color:var(--yellow); border:1px solid var(--yellow); }

    .etext {
      font-size:11px; color:var(--text2); font-family:'IBM Plex Mono',monospace;
      white-space:nowrap; overflow:hidden; text-overflow:ellipsis; transition:color 0.1s;
    }
    .flag-dot { width:6px; height:6px; border-radius:50%; display:inline-block; margin-right:5px; }
    .dot-red    { background: var(--red); }
    .dot-orange { background: var(--orange); }
    .empty { padding:40px; text-align:center; font-size:12px; color:var(--text3); font-family:'IBM Plex Mono',monospace; }

    /* BOTTOM */
    .bottom-row { display:flex; justify-content:flex-end; margin-top:16px; }
    .dl-btn {
      padding:9px 20px; border-radius:8px; border:1px solid var(--border);
      background:var(--bg2); font-size:12px; font-weight:500; color:var(--text2);
      cursor:pointer; font-family:'IBM Plex Sans',sans-serif; transition:all 0.15s;
    }
    .dl-btn:hover { border-color:var(--cyan); color:var(--cyan); background:var(--bg3); }

    /* MODAL */
    .modal-overlay {
      display:none; position:fixed; inset:0;
      background:rgba(0,0,0,0.75); z-index:100;
      align-items:center; justify-content:center; backdrop-filter:blur(3px);
    }
    .modal-overlay.open { display:flex; }
    .modal {
      background:var(--bg2); border-radius:14px; width:500px; max-width:95vw;
      border:1px solid var(--border); box-shadow:0 24px 80px rgba(0,0,0,0.7); overflow:hidden;
    }
    .modal-header {
      padding:16px 20px; display:flex; align-items:center; justify-content:space-between;
      border-bottom:1px solid var(--border2);
    }
    .modal-header.green  { background:var(--green-dim); }
    .modal-header.orange { background:var(--orange-dim); }
    .modal-header.red    { background:var(--red-dim); }
    .verdict-badge { font-size:12px; font-weight:700; padding:4px 14px; border-radius:20px; font-family:'IBM Plex Mono',monospace; }
    .badge-green  { background:var(--green-dim);  color:var(--green);  border:1px solid var(--green); }
    .badge-orange { background:var(--orange-dim); color:var(--orange); border:1px solid var(--orange); }
    .badge-red    { background:var(--red-dim);    color:var(--red);    border:1px solid var(--red); }
    .modal-close  { font-size:18px; cursor:pointer; color:var(--text3); background:none; border:none; transition:color 0.1s; }
    .modal-close:hover { color:var(--text); }
    .modal-body   { padding:18px 20px; }
    .modal-meta   { font-size:10px; letter-spacing:0.08em; color:var(--text3); margin-bottom:10px; font-family:'IBM Plex Mono',monospace; }
    .modal-text   {
      font-size:11px; color:var(--text2); font-family:'IBM Plex Mono',monospace;
      background:var(--bg3); padding:10px 12px; border-radius:6px;
      word-break:break-all; margin-bottom:14px; border:1px solid var(--border2); line-height:1.5;
    }
    .detail-list { list-style:none; margin-bottom:14px; }
    .detail-list li { font-size:12px; color:var(--text2); padding:6px 0; border-bottom:1px solid var(--border2); }
    .detail-list li:last-child { border-bottom:none; }
    .tips-box { background:var(--cyan-dim); border-radius:8px; padding:10px 14px; border:1px solid var(--cyan); }
    .tips-label { font-size:10px; font-weight:600; color:var(--cyan); margin-bottom:6px; letter-spacing:0.08em; font-family:'IBM Plex Mono',monospace; }
    .tips-box li { font-size:12px; color:var(--text2); padding:3px 0; list-style:disc; margin-left:16px; }
    .modal-loading { padding:48px; text-align:center; font-size:12px; color:var(--text3); font-family:'IBM Plex Mono',monospace; }
  </style>
</head>
<body>
<div class="wrap">

  <div class="header">
    <div class="header-left">
      <div class="header-icon">&#128269;</div>
      <div>
        <h1>timeline_analyzer</h1>
        <p>Digital Forensics &amp; Activity Monitor — Kali Linux</p>
      </div>
    </div>
    <span class="live-badge"><span class="live-dot"></span>LIVE</span>
  </div>

  <div class="sec-label">// scan_mode</div>
  <div class="mode-grid">
    <div class="mode-card" id="m1" onclick="runScan('browser',1)">
      <div class="spinner"></div>
      <div class="icon">&#127758;</div>
      <div class="name">Browser</div>
      <div class="sub">chrome history</div>
    </div>
    <div class="mode-card" id="m2" onclick="runScan('file',2)">
      <div class="spinner"></div>
      <div class="icon">&#128193;</div>
      <div class="name">Files</div>
      <div class="sub">.txt files</div>
    </div>
    <div class="mode-card" id="m3" onclick="runScan('log',3)">
      <div class="spinner"></div>
      <div class="icon">&#128220;</div>
      <div class="name">Logs</div>
      <div class="sub">journald</div>
    </div>
    <div class="mode-card" id="m4" onclick="runScan('network',4)">
      <div class="spinner"></div>
      <div class="icon">&#127760;</div>
      <div class="name">Network</div>
      <div class="sub">tcp connections</div>
    </div>
    <div class="mode-card" id="m5" onclick="runScan('dns',5)">
      <div class="spinner"></div>
      <div class="icon">&#128270;</div>
      <div class="name">DNS</div>
      <div class="sub">private traces</div>
    </div>
    <div class="mode-card" id="m6" onclick="runScan('all',6)">
      <div class="spinner"></div>
      <div class="icon">&#128200;</div>
      <div class="name">All Sources</div>
      <div class="sub">full scan</div>
    </div>
  </div>

  <div class="status-bar" id="status"></div>

  <div class="sec-label">// results</div>
  <div class="stats-row">
    <div class="stat-box"><div class="lbl">TOTAL</div>  <div class="val v-total"   id="st">—</div></div>
    <div class="stat-box"><div class="lbl">BROWSER</div><div class="val v-browser" id="sb">—</div></div>
    <div class="stat-box"><div class="lbl">FILES</div>  <div class="val v-file"    id="sf">—</div></div>
    <div class="stat-box"><div class="lbl">LOGS</div>   <div class="val v-log"     id="sl">—</div></div>
    <div class="stat-box"><div class="lbl">NETWORK</div><div class="val v-network" id="sn">—</div></div>
    <div class="stat-box"><div class="lbl">DNS</div>    <div class="val v-dns"     id="sd">—</div></div>
  </div>

  <div class="sec-label">// timeline</div>

  <div class="alert-box" id="alert-box">
    <div class="alert-box-title" id="alert-title"></div>
    <div class="alert-chips" id="alert-chips"></div>
  </div>

  <div class="timeline-box">
    <div class="tl-top">
      <span class="tl-title" id="tl-title">activity_log</span>
      <small id="tl-count">select a mode to begin</small>
    </div>
    <div id="tl">
      <div class="empty">_ click any mode card above to start scanning</div>
    </div>
  </div>

  <div class="bottom-row">
    <button class="dl-btn" onclick="downloadReport()">&#8659;&nbsp; Export report.txt</button>
  </div>

</div>

<!-- MODAL -->
<div class="modal-overlay" id="modal-overlay" onclick="closeModal(event)">
  <div class="modal">
    <div class="modal-loading" id="modal-loading">_ analyzing_event...</div>
    <div id="modal-content" style="display:none">
      <div class="modal-header" id="modal-header">
        <div>
          <div style="font-size:10px;color:var(--text3);margin-bottom:6px;font-family:'IBM Plex Mono',monospace;letter-spacing:0.08em" id="modal-type-label">EVENT_TYPE</div>
          <span class="verdict-badge" id="modal-badge">Safe</span>
        </div>
        <button class="modal-close" onclick="closeModal()">&#10005;</button>
      </div>
      <div class="modal-body">
        <div class="modal-meta" id="modal-type-top"></div>
        <div class="modal-text" id="modal-text-val"></div>
        <ul class="detail-list" id="modal-details"></ul>
        <div class="tips-box" id="modal-tips" style="display:none">
          <div class="tips-label">&#9888; RECOMMENDATIONS</div>
          <ul id="modal-tips-list"></ul>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  let lastEvents=[], displayedEvents=[], isScanning=false;

  async function runScan(mode, n) {
    if (isScanning) return;
    isScanning = true;
    [1,2,3,4,5,6].forEach(i => document.getElementById('m'+i).classList.remove('active','loading'));
    const card = document.getElementById('m'+n);
    card.classList.add('active','loading');
    const labels = {browser:'Browser History',file:'File Events',log:'Log Events',
                    network:'Network Connections',dns:'DNS History',all:'Full Scan'};
    setStatus('info','> scanning ' + labels[mode] + '...');
    document.getElementById('tl-title').textContent = labels[mode].toLowerCase().replaceAll(' ','_');
    document.getElementById('tl-count').textContent = 'scanning...';
    document.getElementById('tl').innerHTML = '<div class="empty">_ scanning in progress...</div>';
    try {
      const res = await fetch('/api/scan/'+mode);
      if (!res.ok) throw new Error();
      const data = await res.json();
      lastEvents = data.events;
      document.getElementById('st').textContent = data.summary.total;
      document.getElementById('sb').textContent = data.summary.browser;
      document.getElementById('sf').textContent = data.summary.file;
      document.getElementById('sl').textContent = data.summary.log;
      document.getElementById('sn').textContent = data.summary.network ?? 0;
      document.getElementById('sd').textContent = data.summary.dns ?? 0;
      renderTimeline(data.events);
      document.getElementById('tl-count').textContent = data.events.length + ' events found';
      showAlertSummary(data.summary);
      setStatus('success','> done. ' + data.summary.total + ' events loaded. report.txt saved.');
    } catch {
      setStatus('error','> error: could not connect. check terminal.');
      document.getElementById('tl').innerHTML = '<div class="empty">_ error loading data</div>';
    }
    card.classList.remove('loading');
    isScanning = false;
  }

  function renderTimeline(events) {
    displayedEvents = events;
    const c = document.getElementById('tl');
    if (!events || !events.length) {
      c.innerHTML = '<div class="empty">_ no events found for this mode</div>';
      return;
    }
    c.innerHTML = events.map((e,i) => {
      const fc = e.flag && e.flag!=='green' ? 'flag-'+e.flag : '';
      const dot = e.flag==='red' ? '<span class="flag-dot dot-red"></span>'
                : e.flag==='orange' ? '<span class="flag-dot dot-orange"></span>' : '';
      return `<div class="event-row ${fc}" onclick="showDetail(${i})" title="Click for analysis">
        <span class="etime">${e.time}</span>
        <span class="etag t-${e.type}">[${e.type.toUpperCase()}]</span>
        <span class="etext">${dot}${e.text}</span>
      </div>`;
    }).join('');
  }

  function showAlertSummary(s) {
    const box=document.getElementById('alert-box'),title=document.getElementById('alert-title'),chips=document.getElementById('alert-chips');
    const mal=s.malicious||0,sus=s.suspicious||0,safe=s.total-mal-sus;
    chips.innerHTML='';
    if (!mal&&!sus) {
      box.className='alert-box has-alerts all-safe';
      title.textContent='✓ all_events_safe — no threats detected';
      chips.innerHTML=`<span class="alert-chip chip-green">✓ ${safe} safe</span>`;
    } else {
      box.className='alert-box has-alerts '+(mal>0?'has-danger':'has-warn');
      title.textContent=mal>0?`! ${mal} malicious + ${sus} suspicious — click highlighted rows`:`! ${sus} suspicious events — click rows for details`;
      if(mal) chips.innerHTML+=`<span class="alert-chip chip-red" onclick="filterEvents('red')">! ${mal} malicious</span>`;
      if(sus) chips.innerHTML+=`<span class="alert-chip chip-orange" onclick="filterEvents('orange')">~ ${sus} suspicious</span>`;
      if(safe) chips.innerHTML+=`<span class="alert-chip chip-green" onclick="filterEvents('green')">✓ ${safe} safe</span>`;
    }
  }

  function filterEvents(flag) {
    const f=flag==='all'?lastEvents:lastEvents.filter(e=>flag==='green'?(!e.flag||e.flag==='green'):e.flag===flag);
    renderTimeline(f);
    document.getElementById('tl-count').textContent=f.length+' events shown';
  }

  async function showDetail(i) {
    const e=displayedEvents[i];
    const overlay=document.getElementById('modal-overlay'),loading=document.getElementById('modal-loading'),mc=document.getElementById('modal-content');
    overlay.classList.add('open');
    loading.style.display='block'; mc.style.display='none';
    try {
      const res=await fetch('/api/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:e.type,text:e.text})});
      const data=await res.json();
      const bm={green:'badge-green',orange:'badge-orange',red:'badge-red'};
      const ic={green:'✓ Safe',orange:'⚠ Suspicious',red:'✕ Malicious'};
      const c=data.color;
      document.getElementById('modal-header').className='modal-header '+c;
      document.getElementById('modal-badge').className='verdict-badge '+bm[c];
      document.getElementById('modal-badge').textContent=ic[c];
      document.getElementById('modal-type-label').textContent=e.type.toUpperCase()+'_EVENT';
      document.getElementById('modal-type-top').textContent='scanned_at: '+e.time;
      document.getElementById('modal-text-val').textContent=e.text;
      document.getElementById('modal-details').innerHTML=data.details.map(d=>`<li>${d}</li>`).join('');
      const tb=document.getElementById('modal-tips'),tl=document.getElementById('modal-tips-list');
      if(data.tips&&data.tips.length){tl.innerHTML=data.tips.map(t=>`<li>${t}</li>`).join('');tb.style.display='block';}
      else tb.style.display='none';
      loading.style.display='none'; mc.style.display='block';
    } catch { loading.textContent='_ error loading analysis'; }
  }

  function closeModal(e) {
    if(!e||e.target===document.getElementById('modal-overlay'))
      document.getElementById('modal-overlay').classList.remove('open');
  }

  function setStatus(type,msg) {
    const bar=document.getElementById('status');
    bar.className='status-bar '+type; bar.textContent=msg;
  }

  function downloadReport() {
    if(!lastEvents.length){alert('Run a scan first.');return;}
    let text='=== Digital Activity Timeline ===\\n\\n';
    lastEvents.forEach(e=>{text+=`${e.time} -> [${e.type.toUpperCase()}] ${e.text}\\n`;});
    const cnt=t=>lastEvents.filter(e=>e.type===t).length;
    text+=`\\n--- Summary ---\\nTotal: ${lastEvents.length}\\nBrowser: ${cnt('browser')}\\nFile: ${cnt('file')}\\nLogs: ${cnt('log')}\\nNetwork: ${cnt('network')}\\nDNS: ${cnt('dns')}\\n`;
    const a=document.createElement('a');
    a.href=URL.createObjectURL(new Blob([text],{type:'text/plain'}));
    a.download='report.txt'; a.click();
  }
</script>
</body>
</html>"""

# ---------------------------
# MAIN
# ---------------------------
if __name__ == "__main__":
    print("[+] Starting Timeline Analyzer...")
    print("[+] Opening browser at http://localhost:5000\n")
    threading.Timer(1.0, lambda: webbrowser.open("http://localhost:5000")).start()
    app.run(debug=False, port=5000)